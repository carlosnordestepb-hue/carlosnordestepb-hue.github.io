# Insigne — site institucional

Site responsivo inspirado em princípios de design observados no site da Tesla:
- navegação enxuta;
- seções de grande impacto;
- tipografia grande;
- CTAs claros;
- uso de espaços amplos;
- narrativa por blocos de conteúdo.

A identidade da Insigne usa a logo original fornecida e as cores visuais da marca (azul-marinho e verde-limão).

## Publicação
Envie os arquivos `index.html`, `styles.css`, `script.js` e a pasta `assets` para sua hospedagem.

O botão de WhatsApp está configurado para o número comercial informado para a Insigne.
